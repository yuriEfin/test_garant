<?php
return [
    'gridview' => [
        'class' => '\kartik\grid\Module'
    ],
];
