<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=garant',
    'username' => 'root',
    'password' => 'aUBEA4VgKpSN',
    'charset' => 'utf8',
    'charset' => 'utf8',
    'tablePrefix' => 'xwp_',
];
