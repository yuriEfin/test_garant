<?php
return [
    'Calculations' => 'Отчеты',
    'Create Calculation' => 'Создать отчет',
    'Updated Calculation' => 'Обновление отчета',
    'Create' => 'Создать',
    'Update' => 'Обновить',
    'Delete' => 'Удалить',
    'Update Calculation' => 'Обновить отчета',
];
