<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%calculation_code}}".
 *
 * @property integer $calculation_id
 * @property string $code
 */
class CalculationCode extends base\CalculationCode
{
    
}
